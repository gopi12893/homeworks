package hw1;

public class Hw1 {
	public static void main(String[] args)
	{
	System.out.print("hello world");
	}

}
